/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2004201301
#define HB_VER_CHLID             "e8cc50254a83714ccb22e78db84a492a419aa576"
#define HB_VER_LENTRY            "2020-04-20 15:01 UTC+0200 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_VER_HB_USER_CFLAGS    "-O2"
#define HB_VER_HB_USER_LDFLAGS   "-Lc:\\bcc7164\\LIB -Lharbour\\lib\\win\\bcc64 "
#define HB_VER_HB_USER_PRGFLAGS  "-l-"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "bcc64"
