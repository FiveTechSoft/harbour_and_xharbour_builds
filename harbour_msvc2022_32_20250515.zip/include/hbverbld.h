/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2503251254lu
#define HB_VER_CHLID             "aef25d8b19f00a4722bab47682911c2f81c0dab8"
#define HB_VER_LENTRY            "2025-03-25 13:54 UTC+0100 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_VER_HB_USER_CFLAGS    "-MD -MP"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "msvc"
