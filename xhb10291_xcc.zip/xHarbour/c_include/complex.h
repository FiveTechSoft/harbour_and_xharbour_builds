#ifndef _COMPLEX_H
#define _COMPLEX_H

/* complex.h - C99 standard header */

#pragma message("complex.h included - no complex math support!")

#endif /* _COMPLEX_H */

