#ifndef _INITGUID_H
#define _INITGUID_H

/* Definitions for controlling GUID initialization */

#define INITGUID
#include <guiddef.h>

#endif /* _INITGUID_H */
