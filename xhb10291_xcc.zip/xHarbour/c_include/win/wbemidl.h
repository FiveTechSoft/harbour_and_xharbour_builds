#ifndef _WBEMIDL_H
#define _WBEMIDL_H

/* WBEM interfaces definitions */

#include <wbemcli.h>
#include <wbemprov.h>
#include <wbemtran.h>
#include <wbemdisp.h>

#endif /* _WBEMIDL_H */
