#ifndef _ADSDB_H
#define _ADSDB_H

/* OLE DB provider for ADSI definitions */

#ifdef __cplusplus
extern "C" {
#endif

#define DBPROPFLAGS_ADSISEARCH  0x0000C000

#ifdef __cplusplus
}
#endif

#endif /* _ADSDB_H */
