#ifndef _SCHNLSP_H
#define _SCHNLSP_H

/* SCHANNEL Security Provider definitions */

#include <schannel.h>

#endif /* _SCHNLSP_H */
