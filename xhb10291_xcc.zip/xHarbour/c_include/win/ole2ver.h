#ifndef _OLE2VER_H
#define _OLE2VER_H

/* Windows OLE 2 Version Number Info */

#define rmm  23
#define rup  639

#endif /* _OLE2VER_H */
