/*
 * pshpack2.h - private header to enable 2 byte structure packing
 */
#pragma pack(push,2)

