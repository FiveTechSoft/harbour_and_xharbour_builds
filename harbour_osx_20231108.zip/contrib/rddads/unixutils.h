/* dummy file for ads.h */
