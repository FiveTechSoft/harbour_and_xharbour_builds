/*
 * $Id$
 */

/*
 * Harbour Project source code:
 *    Version information and build time switches.
 *
 * Copyright 2008 Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 * www - http://www.harbour-project.org
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */


#ifndef __HBVERBLD_INCLUDED
#define __HBVERBLD_INCLUDED

#define HB_VER_GITFAKEID	HB_ULL( 202505151442 )
#define HB_VER_CVSID		HB_ULL( 202505151442 )

#if defined(HB_VER_BUILDDATE)
#undef HB_VER_BUILDDATE
#endif
#define HB_VER_BUILDDATE	20250515

#if defined(HB_VER_CHLCVS)
#undef HB_VER_CHLCVS
#endif

#define HB_VER_CHLCVS	"12e9bbd8d4a23af28478a28765ef425f4a47dae8"

#if defined(HB_VER_LENTRY)
#undef HB_VER_LENTRY
#endif

#define HB_VER_LENTRY	"2025-05-15 14:42 UTC+0200 Enrico Maria Giordano <e.m.giordano@emagsoftware.it>"

#endif /* __HBVERBLD_INCLUDED */
