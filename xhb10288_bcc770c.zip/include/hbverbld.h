/*
 * $Id$
 */

/*
 * Harbour Project source code:
 *    Version information and build time switches.
 *
 * Copyright 2008 Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 * www - http://www.harbour-project.org
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */


#ifndef __HBVERBLD_INCLUDED
#define __HBVERBLD_INCLUDED

#define HB_VER_GITFAKEID	HB_ULL( 202502021138 )
#define HB_VER_CVSID		HB_ULL( 202502021138 )

#if defined(HB_VER_BUILDDATE)
#undef HB_VER_BUILDDATE
#endif
#define HB_VER_BUILDDATE	20250202

#if defined(HB_VER_CHLCVS)
#undef HB_VER_CHLCVS
#endif

#define HB_VER_CHLCVS	"bef644bdd31949a37dc30135d749ebadd7c1e579"

#if defined(HB_VER_LENTRY)
#undef HB_VER_LENTRY
#endif

#define HB_VER_LENTRY	"2025-02-02 11:38 UTC+0100 Enrico Maria Giordano <e.m.giordano@emagsoftware.it>"

#endif /* __HBVERBLD_INCLUDED */
