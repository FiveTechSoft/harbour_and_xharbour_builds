/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             1904111533
#define HB_VER_CHLID             "ba87964f6754d037f86be597c07a08e02f4cb9e0"
#define HB_VER_LENTRY            "2019-04-11 17:33 UTC+0200 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "msvc64"
