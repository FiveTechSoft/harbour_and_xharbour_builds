/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2405310955lu
#define HB_VER_CHLID             "b2c61aa44a4759455b4533dd54a94356cff892ec"
#define HB_VER_LENTRY            "2024-05-31 11:55 UTC+0200 Aleksander Czajczynski (hb fki.pl)"
#define HB_VER_HB_USER_CFLAGS    "-MD -MP -O1"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "msvc"
