/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2404101339lu
#define HB_VER_CHLID             "a149e5544b265c27c683f3e0de504f58249e51fb"
#define HB_VER_LENTRY            "2024-04-10 15:39 UTC+0200 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_VER_HB_USER_LDFLAGS   "-ap -je:\\fw\\temp\\bcc64\\bcc\\lib;e:\\fw\\temp\\bcc64\\bcc\\lib\\psdk"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "bcc64"
