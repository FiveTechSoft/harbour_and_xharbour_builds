/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2502031126lu
#define HB_VER_CHLID             "7dbe0efaa59c5682a84ad4fc6fc54909a3239b4f"
#define HB_VER_LENTRY            "2025-02-03 12:26 UTC+0100 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "mingw"
