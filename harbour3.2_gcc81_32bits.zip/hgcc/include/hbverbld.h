/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             1806032230
#define HB_VER_CHLID             "1b05385b046db903a97f7d79311af9a8ec65b3e8"
#define HB_VER_LENTRY            "2018-06-04 01:30 UTC-0300 Lailton Fernando Mariano (lailton/at/harbour.com.br)"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "mingw"
