/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             1909261630
#define HB_VER_CHLID             "915bc6f07665319275d73fcae450e1621bde4d23"
#define HB_VER_LENTRY            "2019-09-26 18:30 UTC+0200 Maurizio la Cecilia (m.lacecilia/at/gmail.com)"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "bcc"
