/*
 * $Id$
 */

/*
 * Harbour Project source code:
 *    Version information and build time switches.
 *
 * Copyright 2008 Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 * www - http://www.harbour-project.org
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */


#ifndef __HBVERBLD_INCLUDED
#define __HBVERBLD_INCLUDED

#define HB_VER_GITFAKEID	HB_ULL( 202502261652 )
#define HB_VER_CVSID		HB_ULL( 202502261652 )

#if defined(HB_VER_BUILDDATE)
#undef HB_VER_BUILDDATE
#endif
#define HB_VER_BUILDDATE	20250226

#if defined(HB_VER_CHLCVS)
#undef HB_VER_CHLCVS
#endif

#define HB_VER_CHLCVS	"e0586ad8a10484dbdf64acaa646ef6a24f78860a"

#if defined(HB_VER_LENTRY)
#undef HB_VER_LENTRY
#endif

#define HB_VER_LENTRY	"2025-02-26 16:52 UTC+0100 Enrico Maria Giordano <e.m.giordano@emagsoftware.it>"

#endif /* __HBVERBLD_INCLUDED */
