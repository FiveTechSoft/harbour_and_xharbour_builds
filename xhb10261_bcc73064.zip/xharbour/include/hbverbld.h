/*
 * $Id: ppgen.c 10256 2020-02-25 15:36:35Z zsaulius $
 */

/*
 * Harbour Project source code:
 *    Version information and build time switches.
 *
 * Copyright 2008 Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 * www - http://www.harbour-project.org
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */


#ifndef __HBVERBLD_INCLUDED
#define __HBVERBLD_INCLUDED

#define HB_VER_CVSID		10261

#if defined(HB_VER_BUILDDATE)
#undef HB_VER_BUILDDATE
#endif
#define HB_VER_BUILDDATE	20200311 

#if defined(HB_VER_CHLCVS)
#undef HB_VER_CHLCVS
#endif

#define HB_VER_CHLCVS	"ChangeLog 10261 2020-03-11 17:50:20Z zsaulius"

#if defined(HB_VER_LENTRY)
#undef HB_VER_LENTRY
#endif

#define HB_VER_LENTRY	"2020-03-11 19:50 UTC+0200 Saulius Zrelskis <labitas/AT/gmail/com>"

#endif /* __HBVERBLD_INCLUDED */
