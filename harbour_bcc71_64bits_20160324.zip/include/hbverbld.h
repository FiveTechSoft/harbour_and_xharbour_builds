/*
 * Version information and build time switches.
 *
 * Copyright 2008-2016 Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             1603181642
#define HB_VER_CHLID             "e1709822f338c515c96c40b3990f20c19b0d45e5"
#define HB_VER_LENTRY            "2016-03-18 17:42 UTC+0100 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "bcc64"
