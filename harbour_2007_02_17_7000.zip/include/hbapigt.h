/*
 * $Id: hbapigt.h 6998 2007-02-13 19:59:41Z druzus $
 */

/*
 * Harbour Project source code:
 * Header file for the Terminal API
 *
 * Copyright 1999 {list of individual authors and e-mail addresses}
 * www - http://www.harbour-project.org
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA (or visit the web site http://www.gnu.org/).
 *
 * As a special exception, the Harbour Project gives permission for
 * additional uses of the text contained in its release of Harbour.
 *
 * The exception is that, if you link the Harbour libraries with other
 * files to produce an executable, this does not by itself cause the
 * resulting executable to be covered by the GNU General Public License.
 * Your use of that executable is in no way restricted on account of
 * linking the Harbour library code into it.
 *
 * This exception does not however invalidate any other reasons why
 * the executable file might be covered by the GNU General Public License.
 *
 * This exception applies only to the code released by the Harbour
 * Project under the name Harbour.  If you copy code from other
 * Harbour Project or Free Software Foundation releases into a copy of
 * Harbour, as the General Public License permits, the exception does
 * not apply to the code that you add in this way.  To avoid misleading
 * anyone as to the status of such modified files, you must delete
 * this exception notice from them.
 *
 * If you write modifications of your own for Harbour, it is your choice
 * whether to permit this exception to apply to your modifications.
 * If you do not wish that, delete this exception notice.
 *
 */

/*
 * The following parts are Copyright of the individual authors.
 * www - http://www.harbour-project.org
 *
 * Copyright 1999 David G. Holm <dholm@jsd-llc.com>
 *    Keyboard related declarations
 *    Cursor declarations
 * See above for licensing terms.
 *
 * Copyright 1999-2001 Viktor Szakats <viktor.szakats@syenar.hu>
 *    Mouse related declarations
 *    Undocumented GT API declarations
 *
 * Copyright 2005 Przemyslaw Czerpak < druzus /at/ priv.onet.pl >
 *    Internal GT code reimplemented in differ way
 *
 * See doc/license.txt for licensing terms.
 *
 */

#ifndef HB_APIGT_H_
#define HB_APIGT_H_
#include "hbapi.h"

HB_EXTERN_BEGIN

#include "inkey.ch"
#include "setcurs.ch"
#include "hbgtinfo.ch"

/* Cursor style constants */
#define SC_UNDEF       -1     /* undefined */
#define SC_NONE         0     /* None */
#define SC_NORMAL       1     /* Underline */
#define SC_INSERT       2     /* Lower half block */
#define SC_SPECIAL1     3     /* Full block */
#define SC_SPECIAL2     4     /* Upper half block */

/* maximum length of color string */
#define CLR_STRLEN              64

/* attributes for color strings, these are the same as the ones in color.ch
   but prefixed with HB_ to avoid collision. */
#define HB_CLR_STANDARD         0
#define HB_CLR_ENHANCED         1
#define HB_CLR_BORDER           2
#define HB_CLR_BACKGROUND       3
#define HB_CLR_UNSELECTED       4
#define HB_CLR_MAX_             HB_CLR_UNSELECTED


/* strings for borders (same as box.ch, but defined for use by C) */

/* Note. This part will never be used, but is being kept in the source,
         so that if you use code page 437, you can see what the line
         draw characters are supposed to look like.
                                01234567
#define _B_SINGLE              "�Ŀ�����"
#define _B_DOUBLE              "�ͻ���Ⱥ"
#define _B_SINGLE_DOUBLE       "�ķ���Ӻ"
#define _B_DOUBLE_SINGLE       "�͸���Գ"
#define HB_B_SINGLE_V          '�'
#define HB_B_SINGLE_H          '�'
#define HB_B_DOUBLE_V          '�'
#define HB_B_DOUBLE_H          '�'
*/
#define _B_SINGLE              "\xDA\xC4\xBF\xB3\xD9\xC4\xC0\xB3"
#define _B_DOUBLE              "\xC9\xCD\xBB\xBA\xBC\xCD\xC8\xBA"
#define _B_SINGLE_DOUBLE       "\xD6\xC4\xB7\xBA\xBD\xC4\xD3\xBA"
#define _B_DOUBLE_SINGLE       "\xD5\xCD\xB8\xB3\xBE\xCD\xD4\xB3"
#define HB_B_SINGLE_V          '\xB3'
#define HB_B_SINGLE_H          '\xC4'
#define HB_B_DOUBLE_V          '\xBA'
#define HB_B_DOUBLE_H          '\xCD'

#if defined( HB_COMPAT_C53 ) && !defined( HB_C52_STRICT )
#  define HB_DEFAULT_INKEY_BUFSIZE  50
#else
#  define HB_DEFAULT_INKEY_BUFSIZE  15
#endif


/* structure used to pass/receive parameters in hb_gtInfo() */

typedef struct
{
   PHB_ITEM pNewVal;
   PHB_ITEM pResult;
} HB_GT_INFO, * PHB_GT_INFO;

/* Public interface. These should never change, only be added to. */

extern HB_EXPORT ERRCODE hb_gtInit( FHANDLE hFilenoStdin, FHANDLE hFilenoStdout, FHANDLE hFilenoStderr );
extern HB_EXPORT ERRCODE hb_gtExit( void );
extern HB_EXPORT ERRCODE hb_gtBox( SHORT uiTop, SHORT uiLeft, SHORT uiBottom, SHORT uiRight, BYTE * pbyFrame );
extern HB_EXPORT ERRCODE hb_gtBoxD( SHORT uiTop, SHORT uiLeft, SHORT uiBottom, SHORT uiRight );
extern HB_EXPORT ERRCODE hb_gtBoxS( SHORT uiTop, SHORT uiLeft, SHORT uiBottom, SHORT uiRight );
extern HB_EXPORT ERRCODE hb_gtColorSelect( USHORT uiColorIndex );
extern HB_EXPORT USHORT  hb_gtColorToN( char * szColorString );
extern HB_EXPORT ERRCODE hb_gtDispBegin( void );
extern HB_EXPORT USHORT  hb_gtDispCount( void );
extern HB_EXPORT ERRCODE hb_gtDispEnd( void );
extern HB_EXPORT ERRCODE hb_gtDrawShadow( USHORT uiTop, USHORT uiLeft, USHORT uiBottom, USHORT uiRight, BYTE byAttr );
extern HB_EXPORT ERRCODE hb_gtGetBlink( BOOL * pbBlink );
extern HB_EXPORT ERRCODE hb_gtGetColorStr( char * pszColorString );
extern HB_EXPORT ERRCODE hb_gtGetCursor( USHORT * puiCursorShape );
extern HB_EXPORT ERRCODE hb_gtGetPos( SHORT * piRow, SHORT * piCol );
extern HB_EXPORT BOOL    hb_gtIsColor( void );
extern HB_EXPORT USHORT  hb_gtMaxCol( void );
extern HB_EXPORT USHORT  hb_gtMaxRow( void );
extern HB_EXPORT ERRCODE hb_gtPostExt( void );
extern HB_EXPORT ERRCODE hb_gtPreExt( void );
extern HB_EXPORT ERRCODE hb_gtSuspend( void ); /* prepare the reminal for shell output */
extern HB_EXPORT ERRCODE hb_gtResume( void ); /* resume the terminal after the shell output */
extern HB_EXPORT int     hb_gtReadKey( int iEventMask );
extern HB_EXPORT ERRCODE hb_gtRectSize( int iTop, int iLeft, int iBottom, int iRight, ULONG * puiBuffSize );
extern HB_EXPORT ERRCODE hb_gtRepChar( USHORT uiRow, USHORT uiCol, BYTE byChar, USHORT uiCount );
extern HB_EXPORT ERRCODE hb_gtSave( USHORT uiTop, USHORT uiLeft, USHORT uiBottom, USHORT uiRight, void * pScrBuff );
extern HB_EXPORT ERRCODE hb_gtRest( USHORT uiTop, USHORT uiLeft, USHORT uiBottom, USHORT uiRight, void * pScrBuff );
extern HB_EXPORT ERRCODE hb_gtGetChar( USHORT uiRow, USHORT uiCol, BYTE * pbColor, BYTE * pbAttr, USHORT * pusChar );
extern HB_EXPORT ERRCODE hb_gtPutChar( USHORT uiRow, USHORT uiCol, BYTE bColor, BYTE bAttr, USHORT usChar );
extern HB_EXPORT ERRCODE hb_gtBeginWrite( void );
extern HB_EXPORT ERRCODE hb_gtEndWrite( void );
extern HB_EXPORT ERRCODE hb_gtScrDim( USHORT * puiHeight, USHORT * puiWidth );
extern HB_EXPORT ERRCODE hb_gtScroll( USHORT uiTop, USHORT uiLeft, USHORT uiBottom, USHORT uiRight, SHORT iRows, SHORT iCols );
extern HB_EXPORT ERRCODE hb_gtScrollUp( USHORT uiRows );
extern HB_EXPORT ERRCODE hb_gtSetAttribute( USHORT uiTop, USHORT uiLeft, USHORT uiBottom, USHORT uiRight, BYTE byAttr );
extern HB_EXPORT ERRCODE hb_gtSetBlink( BOOL bBlink );
extern HB_EXPORT ERRCODE hb_gtSetColorStr( const char * pszColorString );
extern HB_EXPORT ERRCODE hb_gtSetCursor( USHORT uiCursorShape );
extern HB_EXPORT ERRCODE hb_gtSetMode( USHORT uiRows, USHORT uiCols );
extern HB_EXPORT ERRCODE hb_gtSetPos( SHORT iRow, SHORT iCol );
extern HB_EXPORT ERRCODE hb_gtSetSnowFlag( BOOL bNoSnow );
extern HB_EXPORT ERRCODE hb_gtTone( double dFrequency, double dDuration );
extern HB_EXPORT ERRCODE hb_gtWrite( BYTE * pbyStr, ULONG ulLen );
extern HB_EXPORT ERRCODE hb_gtWriteAt( USHORT uiRow, USHORT uiCol, BYTE * pbyStr, ULONG ulLen );
extern HB_EXPORT ERRCODE hb_gtWriteCon( BYTE * pbyStr, ULONG ulLen );
extern HB_EXPORT char *  hb_gtVersion( int iType );
extern HB_EXPORT ERRCODE hb_gtOutStd( BYTE * pbyStr, ULONG ulLen );
extern HB_EXPORT ERRCODE hb_gtOutErr( BYTE * pbyStr, ULONG ulLen );
extern HB_EXPORT ERRCODE hb_gtSetDispCP( char * pszTermCDP, char * pszHostCDP, BOOL fBox );
extern HB_EXPORT ERRCODE hb_gtSetKeyCP( char * pszTermCDP, char * pszHostCDP );
extern HB_EXPORT ERRCODE hb_gtInfo( int iType, PHB_GT_INFO pInfo );
extern HB_EXPORT int     hb_gtAlert( PHB_ITEM pMessage, PHB_ITEM pOptions, int iClrNorm, int iClrHigh, double dDelay );
extern HB_EXPORT int     hb_gtSetFlag( int iType, int iNewValue );
extern HB_EXPORT int     hb_gtGfxPrimitive( int iType, int iTop, int iLeft, int iBottom, int iRight, int iColor );
extern HB_EXPORT ERRCODE hb_gtGfxText( int iTop, int iLeft, char * szText, int iColor, int iSize, int iWidth );
       
extern HB_EXPORT BOOL    hb_mouseIsPresent( void );
extern HB_EXPORT BOOL    hb_mouseGetCursor( void );
extern HB_EXPORT void    hb_mouseSetCursor( BOOL bVisible );
extern HB_EXPORT int     hb_mouseCol( void );
extern HB_EXPORT int     hb_mouseRow( void );
extern HB_EXPORT void    hb_mouseGetPos( int * piRow, int * piCol );
extern HB_EXPORT void    hb_mouseSetPos( int iRow, int iCol );
extern HB_EXPORT void    hb_mouseSetBounds( int iTop, int iLeft, int iBottom, int iRight );
extern HB_EXPORT void    hb_mouseGetBounds( int * piTop, int * piLeft, int * piBottom, int * piRight );
extern HB_EXPORT int     hb_mouseStorageSize( void );
extern HB_EXPORT void    hb_mouseSaveState( BYTE * pBuffer );
extern HB_EXPORT void    hb_mouseRestoreState( BYTE * pBuffer );
extern HB_EXPORT int     hb_mouseGetDoubleClickSpeed( void );
extern HB_EXPORT void    hb_mouseSetDoubleClickSpeed( int iSpeed );
extern HB_EXPORT int     hb_mouseCountButton( void );
extern HB_EXPORT BOOL    hb_mouseButtonState( int iButton );
extern HB_EXPORT BOOL    hb_mouseButtonPressed( int iButton, int * piRow, int * piCol );
extern HB_EXPORT BOOL    hb_mouseButtonReleased( int iButton, int * piRow, int * piCol );
extern HB_EXPORT int     hb_mouseReadKey( int iEventMask );


/* Undocumented CA-Clipper 5.x GT API calls */

#define HB_GT_RECT void
#define HB_GT_WND void
#define HB_GT_RGB void
#define HB_GT_SLR void

extern HB_EXPORT void    hb_gtWCreate( HB_GT_RECT * rect, HB_GT_WND ** wnd );
extern HB_EXPORT void    hb_gtWDestroy( HB_GT_WND * wnd );
extern HB_EXPORT BOOL    hb_gtWFlash( void );
extern HB_EXPORT void    hb_gtWApp( HB_GT_WND ** wnd );
extern HB_EXPORT void    hb_gtWCurrent( HB_GT_WND * wnd );
extern HB_EXPORT void    hb_gtWPos( HB_GT_WND * wnd, HB_GT_RECT * rect );
extern HB_EXPORT BOOL    hb_gtWVis( HB_GT_WND * wnd, USHORT uiStatus );
       
extern HB_EXPORT ERRCODE hb_gtSLR( HB_GT_SLR * pSLR ); /* System Level Request */
extern HB_EXPORT ERRCODE hb_gtModalRead( void * );
extern HB_EXPORT ERRCODE hb_gtFlushCursor( void );
extern HB_EXPORT ERRCODE hb_gtSetColor( HB_GT_RGB * color );
extern HB_EXPORT ERRCODE hb_gtGetColor( HB_GT_RGB * color );
extern HB_EXPORT ERRCODE hb_gtSetBorder( HB_GT_RGB * color );


/* Keyboard related declarations */

#define HB_BREAK_FLAG 256 /* 256, because that's what DJGPP returns Ctrl+Break as.
                             Clipper has no key code 256, so it may as well be
                             used for all the Harbour builds that need it */

#define INKEY_RAW 256   /* Minimally Decoded Keyboard Events */

/* Harbour keyboard support functions */
extern HB_EXPORT int     hb_inkey( BOOL bWait, double dSeconds, int iEvenMask ); /* Wait for keyboard input */
extern HB_EXPORT int     hb_inkeyGet( int iEvenMask );   /* Extract the next key from the Harbour keyboard buffer */
extern HB_EXPORT void    hb_inkeyPut( int ch );          /* Inserts an inkey code into the keyboard buffer */
extern HB_EXPORT int     hb_inkeyLast( int iEvenMask );  /* Return the value of the last key that was extracted */
extern HB_EXPORT int     hb_inkeyNext( int iEvenMask );  /* Return the next key without extracting it */
extern HB_EXPORT void    hb_inkeyPoll( void );           /* Poll the console keyboard to stuff the Harbour buffer */
extern HB_EXPORT void    hb_inkeyReset( void );          /* Reset the Harbour keyboard buffer */
extern HB_EXPORT int     hb_inkeyTranslate( int key, int iEvenMask ); /* Translation extended codes to normal codes, if needed */
extern HB_EXPORT void    hb_inkeySetCancelKeys( int CancelKey, int CancelKeyEx ); /* Set keycodes for Cancel key (usually K_ALT_C) */
extern HB_EXPORT int     hb_setInkeyLast( int iKey );
extern HB_EXPORT void    hb_inkeyExit( void );

/* SetKey related declarations */

extern HB_EXPORT void    hb_setkeyInit( void );
extern HB_EXPORT void    hb_setkeyExit( void );


HB_EXTERN_END

#endif /* HB_APIGT_H_ */
