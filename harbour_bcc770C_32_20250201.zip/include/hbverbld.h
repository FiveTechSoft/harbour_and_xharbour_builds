/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2501301859lu
#define HB_VER_CHLID             "16e8122060316c6ae164b8afa51130f074239658"
#define HB_VER_LENTRY            "2025-01-30 19:59 UTC+0100 Aleksander Czajczynski (hb fki.pl)"
#define HB_VER_HB_USER_CFLAGS    "-w-"
#define HB_VER_HB_USER_LDFLAGS   "-ap -Le:\\fw\\temp\\bcc32c\\lib -Le:\\fw\\temp\\bcc32c\\lib\\psdk"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "bcc32c"
