/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2502110321lu
#define HB_VER_CHLID             "b14dde820de5b827f0c977a7a6e77e1fea7f3ea1"
#define HB_VER_LENTRY            "2025-02-11 04:21 UTC+0100 Antonio Linares (alinares/at/fivetechsoft.com)"
#define HB_VER_HB_USER_CFLAGS    "-MD -MP"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "msvc64"
