/*
 * Version information and build time switches.
 *
 * Copyright 2008-present Przemyslaw Czerpak <druzus / at / priv.onet.pl>
 *
 * This file is generated automatically by Harbour preprocessor
 * and is covered by the same license as Harbour PP
 */

#define HB_VER_REVID             2403071241lu
#define HB_VER_CHLID             "e1736f5706949f000201813e77bb407d3a2d3b38"
#define HB_VER_LENTRY            "2024-03-07 13:41 UTC+0100 Przemyslaw Czerpak (druzus/at/poczta.onet.pl)"
#define HB_VER_HB_USER_CFLAGS    "-MD -MP -O1"
#define HB_PLATFORM              "win"
#define HB_COMPILER              "msvc64"
